import { Component, OnInit} from '@angular/core';
import {FormControl, FormGroup, Validators} from '@angular/forms';
import {ApiserviceService} from '../apiservice.service';
import { ActivatedRoute} from '@angular/router';

@Component({
  selector: 'app-updateproduct',
  templateUrl: './updateproduct.component.html',
  styleUrls: ['./updateproduct.component.css']
})

export class UpdateproductComponent implements OnInit {

  productForm = new FormGroup({
    'productID':new FormControl('',Validators.required),
    'productName':new FormControl('',Validators.required),
    'Category':new FormControl('',Validators.required)
  });

  constructor(private service:ApiserviceService,  private router:ActivatedRoute) { }

  errormsg:any;
  successmsg:any;
  getparamid:any;
  message: boolean= false;

  ngOnInit(): void {

      this.service.getOneproduct(this.router.snapshot.params['id']).subscribe((res:any)=>{
        console.log(res,'res==>');
        this.productForm.patchValue({
          productID:res.data[0].productID,
          productName:res.data[0].productName,
          Category:res.data[0].Category

        });
      });
  }
//to update a product
productUpdate()
{
  console.log(this.productForm.value);
    this.service.updateproduct(this.router.snapshot.params['id'], this.productForm.value).subscribe((result:any)=>{

    this.productForm.reset();
    this.successmsg = 'Profile successfully updated';
    this.message = true;

    });
  }
removeMessage(){
  this.message = false;
}
}