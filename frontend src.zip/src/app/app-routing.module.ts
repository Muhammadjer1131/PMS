import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AboutusComponent } from './aboutus/aboutus.component';
import { HomeComponent } from './home/home.component';
import { NavbarComponent } from './navbar/navbar.component';
import { FaqComponent } from './faq/faq.component';
import { AddproductComponent } from './addproduct/addproduct.component';
import { UpdateproductComponent } from './updateproduct/updateproduct.component';
import { ViewproductComponent } from './viewproduct/viewproduct.component';
import { HttpClientModule } from '@angular/common/http';
import {FormsModule,ReactiveFormsModule} from '@angular/forms';
import { ApiserviceService } from './apiservice.service';

const routes: Routes = 
[
  { path: "aboutus", component:AboutusComponent},
  { path: "navbar", component:NavbarComponent},
  { path: "home", component:HomeComponent},
  { path: "faq", component:FaqComponent},
  { path: "addproduct", component:AddproductComponent},
  { path: "updateproduct/:id", component:UpdateproductComponent},
  { path: "viewproduct", component:ViewproductComponent},

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
