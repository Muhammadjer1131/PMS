<?php

// route
require __DIR__ . '/Controllers/product.php';