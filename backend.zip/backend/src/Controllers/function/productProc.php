<?php 
//get all Product
function getAllproduct($db) {

    
    $sql = 'Select * FROM product '; 
    $stmt = $db->prepare ($sql); 
    $stmt ->execute(); 
    return $stmt->fetchAll(PDO::FETCH_ASSOC); 
} 

//get product by id 
function getproduct($db, $productId) {

    $sql = 'Select o.productID, o.productName, o.Category FROM product o  ';
    $sql .= 'Where o.id = :id';
    $stmt = $db->prepare ($sql);
    $id = (int) $productId;
    $stmt->bindParam(':id', $id, PDO::PARAM_INT);
    $stmt->execute();
    return $stmt->fetchAll(PDO::FETCH_ASSOC); 

}

//add new product
function createproduct($db, $form_data) { 
    //stop at sini
    $sql = 'Insert into product ( productID, productName, Category)'; 
    $sql .= 'values (:productID, :productName, :Category)';  
    $stmt = $db->prepare ($sql); 
    $stmt->bindParam(':productID', $form_data['productID']);  
    $stmt->bindParam(':productName', ($form_data['productName']));
    $stmt->bindParam(':Category', ($form_data['Category']));
    $stmt->execute(); 
    return $db->lastInsertID();
}


//delete product by id 
function deleteproduct($db,$productId) { 

    $sql = ' Delete from product where id = :id';
    $stmt = $db->prepare($sql);  
    $id = (int)$productId; 
    $stmt->bindParam(':id', $id, PDO::PARAM_INT); 
    $stmt->execute(); 
} 

//update product by id 
function updateproduct($db,$form_dat,$productId) { 

    
    $sql = 'UPDATE product SET productID = :productID, productName = :productName , Category = :Category'; 
    $sql .=' WHERE id = :id'; 
    $stmt = $db->prepare ($sql); 
    $id = (int)$productId;  
    $stmt->bindParam(':id', $id, PDO::PARAM_INT);
    $stmt->bindParam(':productID', $form_dat['productID']);    
    $stmt->bindParam(':productName', ($form_dat['productName']));
    $stmt->bindParam(':Category', ($form_dat['Category']));
    $stmt->execute(); 
}
